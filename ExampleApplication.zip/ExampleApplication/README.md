Diese Applikation dient als Beispiel App und soll lediglich den Lernfortschritt aufzeigen.
